% NunchukJoystickState is the class that creates the data structure for storing the
% Joystick values from the Nunchuk

classdef NunchukJoystickState
    
    properties 
        
        X = 0;
        Y = 0;
        
    end % properties
    
end
    