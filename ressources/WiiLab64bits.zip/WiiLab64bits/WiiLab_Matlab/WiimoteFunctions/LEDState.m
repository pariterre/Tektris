% LEDState is the class that creates the data structure for 
% the Wiimotes LED values

classdef LEDState
    
    properties
        
        LED1 = false
        LED2 = false
        LED3 = false
        LED4 = false
        
    end
    
end