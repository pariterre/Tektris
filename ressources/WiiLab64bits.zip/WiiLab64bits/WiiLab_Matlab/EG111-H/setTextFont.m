function setTextFont(tx, ft)
% setTextFont(tx, ft)
% sets tx's font to ft

set(tx, 'FontName', ft)

