function tx = writeText(x, y, s)
%	usage:      writeText(x, y, string)
%	purpose:	Displays the text string at location (x, y) on the window

tx = text(x, y, s);

