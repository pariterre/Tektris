function setTextColor(tx, col)
% setTextColor(tx, col)
% sets tx's color to col

set(tx, 'Color', col)

