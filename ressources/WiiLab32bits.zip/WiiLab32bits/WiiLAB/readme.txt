
WWWWWW          wwwwww          LLLLL          AAAA      BBBBBBB
 WWWW            WWWW           LLLL          AAAAAA     BBB   BB
  WWWW          WWWW            LLLL         AAA  AAA    BBB   BB
   WWWW   WW   WWWW    ii  ii   LLLL        AAA    AAA   BBBBBBB
    WWWW WWWW WWWW              LLLL       AAAAAAAAAAAA  BBB   BB
     WWWWWWWWWWWW      ii  ii   LLLLL      AAAAAAAAAAAA  BBB    BB
      WWWW  WWWW       ii  ii   LLLLLLLLL  AAAA    AAAA  BBB    BB
       WW    WW        iii iii  LLLLLLLLL  AAAA    AAAA  BBBBBBBB



WiiLAB (v1.1)
University of Notre Dame
by Jordan Brindza and Jessica Szweda
(2008)


WiiLAB is a MATLAB Library for Nintendo's Wiimote. 


System Requirements:
WiiLAB is designed for Windows XP and MATLAB v7.6.0(R2008a)


For more information, please visit the project wikis.

For project details, including an extended description and progress reports:

http://snoopy.cse.nd.edu/dokuwiki/doku.php?id=wiimote_interactions_for_freshman_engineering_education

For documentation and how-to guides:

http://netscale.cse.nd.edu/twiki/bin/view/Edu/WiiMote


##############################################################################

WiiLAB is built around the WiimoteLib from Brian Peek.

Copyright 2007-2008 Brian Peek
http://www.brianpeek.com/
http://blogs.msdn.com/coding4fun/archive/2007/03/14/1879033.aspx

Licensed under the terms of the Microsoft Permissive License (Ms-Pl).

##############################################################################






